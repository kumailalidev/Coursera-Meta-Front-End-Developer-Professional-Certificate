import React from "react";
import Fruits from "./Fruits";
import FruitsCounter from "./FruitsCounter";

// Lifting up state means moving state up from a child to the parent component - meaning that a
// previously stateless parent component becomes a stateful component, and a previously stateful
// child component becomes a stateless component. 

function App() {
  const [fruits] = React.useState([
    {fruitName: 'apple', id: 1},
    {fruitName: 'apple', id: 2},
  ]);

  return (
    <div className="App">
      <h1>Where should the state go?</h1>
      <Fruits fruits={fruits}/>
      <FruitsCounter fruits={fruits}/>
    </div>
  );
}

export default App;
