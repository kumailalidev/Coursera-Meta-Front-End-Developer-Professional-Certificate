function FruitsCounter(props) {
    return (
        <div>
            <h2>{props.fruits.length}</h2>
        </div>
    )
}

export default FruitsCounter;