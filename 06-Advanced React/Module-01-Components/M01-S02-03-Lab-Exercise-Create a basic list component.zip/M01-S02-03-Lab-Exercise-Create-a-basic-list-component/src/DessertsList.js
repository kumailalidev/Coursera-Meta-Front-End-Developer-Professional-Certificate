function DessertsList(props) {
  // Implement the component here.
  
  // filter desserts by calories less than 500
  const filteredDesserts = props.data.filter(dessert => {
    return dessert.calories < 500
  })

  // sorting filtered desserts by calories
  const sortedDesserts = filteredDesserts.sort((a, b) => a.calories - b.calories)

  // using map() function for desired output
  const listItems = sortedDesserts.map(dessert => {
    return <li>{dessert.name} - {dessert.calories} cal</li>
  })
  console.log(listItems)
  return (
    <div>
      <ul>
        {listItems}
      </ul>
    </div>
  )
}
export default DessertsList;

/**
 * Can also be done in a following way:

  const DessertsList = (props) => {
  const lowCaloriesDesserts = props.data
    .filter((dessert) => {
      return dessert.calories < 500;
    })
    .sort((a, b) => { 
      return a.calories - b.calories; 
    })
    .map((dessert) => { 
      return ( 
        <li>
          {dessert.name} - {dessert.calories} cal 
        </li> 
      ); 
    }); 
  return <ul>{lowCaloriesDesserts}</ul>; 

  }
  export default DessertsList; 

*/
